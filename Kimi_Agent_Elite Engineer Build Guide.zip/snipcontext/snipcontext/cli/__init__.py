"""SnipContext CLI."""
