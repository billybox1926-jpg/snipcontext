"""Configuration management for SnipContext."""
