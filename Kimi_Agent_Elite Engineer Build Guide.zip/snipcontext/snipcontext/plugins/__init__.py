"""Plugin system for SnipContext."""
