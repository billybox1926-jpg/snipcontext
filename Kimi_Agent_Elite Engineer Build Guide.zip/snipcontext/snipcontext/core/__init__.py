"""Core engine for SnipContext."""
